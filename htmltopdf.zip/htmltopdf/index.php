<?php

if (!isset($_SESSION)){
    session_start();
}

	echo "
	<style>
	
		.button-class {
		border: 1px solid;
		background-color: coral;
		text-decoration: none;
		padding: 3px;
		}
	</style>
	
    <div id='text'>
    <table>
        <tbody>
            <tr>
                <td colspan='2'> LOGO::     Nursery Name </td>
            </tr>
            <tr>
                <td colspan='2'> <b> Intake Information: </b> </td>
            </tr>
            <tr>
                <td> Account Name: Nursery Name </td>
                <td> Account Number: 69584323411 </td>
            </tr>
            <tr>
                <td> Amount: 100 </td>
                <td> Deposite Currency: pound </td>
            </tr>
            <tr>
                <td colspan='2'> <b> Child Information: </b> </td>
            </tr>
            <tr>
                <td> Child ID: ". $_SESSION['childID']." </td>
                <td> Child Name: ". $_SESSION['childFName']." ". $_SESSION['childLName']." </td>
            </tr>
            <tr>
                <td> Category: ". $_SESSION['category']." </td>
                <td> Year: ". $_SESSION['EduYear']." </td>
            </tr>
            <tr>
                <td colspan='2'>
                    <p>
                        In Case you will pay in cash at the Nurcery please make sure to print this document and bring it with you 
                        otherwise if you are going to deal with the bank please make sure to get the signature of the bank on this paper and 
                        submit it to the nurcery managment office .. thanks
                    </p>
                </td>
            </tr>
        </tbody>
    </table>
</div> ";

?>